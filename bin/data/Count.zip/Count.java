package data;

public class Count {
	
	//각 클래스의 객체 개수 셀 변수
	
	public static int userCount;
	public static int bookCount;
	public static int authorCount;
	public static int blackUserCount;
	public static int extensionCount;
	public static int overdueCount;
	public static int publisherCount;
	public static int rentalCount;
	public static int returnCount;
	public static int reviewCount;
	public static int reserveCount;
	
	static {
		userCount = ReadFile.users.size();
		bookCount = ReadFile.books.size();
		authorCount = ReadFile.authors.size();
		blackUserCount = ReadFile.blackUsers.size();
		extensionCount = ReadFile.extensions.size();
		overdueCount = ReadFile.overdues.size();
		publisherCount = ReadFile.publishers.size();
		rentalCount = ReadFile.rentals.size();
		returnCount = ReadFile.returns.size();
		reserveCount = ReadFile.reserves.size();
		
//		reviewCount = ReadFile.reviews.size();
	}

}
